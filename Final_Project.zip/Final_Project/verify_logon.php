<?php
// verify_logon.php - Verify Logon
// Written by: Michael Baranowski, December 2022

  if (!$logon) {
      	header('Location: website.php'); 
	exit;
	}
?>