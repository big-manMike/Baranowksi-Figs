<?php
// home.php - Home Page
// Written by:  Michael Baranowski, December 2022

// Verify that program was called from xx.php
	require('landing.php');

//Variables
//$home_width=$width-20;

// Output Page  
	echo "<center>
		  <h1>Home</h1>
		  <p> Hello, this is Baranowski's Figs and this website is for anyone that wants to learn about figs.
		  <p> You will be able to find what kind of figs are there, how to grow them, and some recipes for figs.
		  <p> This website is mean't for both people new and experienced with figs.
		  <p> Welcome $sname!
		  <p><img width=450 height=450 src='images/fig_home.jpg'>
		  </center>";
?>