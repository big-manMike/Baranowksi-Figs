-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 16, 2022 at 04:06 AM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bcs350`
--

-- --------------------------------------------------------

--
-- Table structure for table `figs`
--

DROP TABLE IF EXISTS `figs`;
CREATE TABLE IF NOT EXISTS `figs` (
  `figid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `info` varchar(250) NOT NULL,
  `color` varchar(20) NOT NULL,
  `photo` varchar(250) NOT NULL,
  PRIMARY KEY (`figid`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `figs`
--

INSERT INTO `figs` (`figid`, `name`, `info`, `color`, `photo`) VALUES
(1, 'Chicago Hardy', 'Know for being a cold hardy (meaning that it can survive temps of freezing for a long period of time). Inside of fruit is a vibrant shade of red. Easy to grow. Sweet and rich flavor allows it to be eat itself or used in salads or charcuteries.', 'Purple', 'images/chicago_hardy.jpg'),
(2, 'Peters Honey', 'Very Sweet and has an amber colored flesh. Can eat by itself or make preserves out of it. Need a lot of sun and heat to ripen.', 'Light Green', 'images/peters_honey_fig.jpg'),
(3, 'Black Mission', 'Most common variety. Small with solid pink flesh and a chewy texture. Good to eat plain. Originated in Spain', 'Black', 'images/black_mission.jpg'),
(4, 'Mediterranean', 'Red Flesh. High sugar content makes it great for drying or using in fig bars and pastes.', 'Light Green', 'images/mediterranean_fig.jpg'),
(5, 'Celeste', 'Ripen early and have high sugar content so they can be used in desserts', 'Brown', 'images/celeste_fig.jpg'),
(6, 'Brown Turkey', 'Bigger fruits light pink flesh with fewer seeds than other figs. They have a milder flavor than others. Can be used in salads', 'Brown', 'images/brown_turkey_fig.jpg'),
(7, 'Calimyrna', 'Large, soft, delicious fruits. Pink insides. Great choice to serve by itself or serve with nuts.', 'Light Green', 'images/calimyrna_fig.jpg'),
(8, 'Kadota', 'Less sweet than other figs, pale interior. Can be heated up with other foods or used in jams and preserves', 'Light Green', 'images/kadota_fig.jpg'),
(9, 'Caprifigs', 'Only produce male flowers and never bear fruit. Only purpose is to pollinate other fig trees', 'Light Green', 'images/caprifig.jpg'),
(10, 'LSU Improved Celeste', 'Ripens early produces a lot of fruit. Provides sweet sugar taste. Dark amber flesh. Fun Fact: LSU Improved Celeste was selectively bred by Louisiana State University (LSU) researchers and spread quickly in the area without LSU formally releasing it.', 'Brown/Purple', 'images/LSU_improved_celeste_fig.jpg');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
