<?php
// offline.php - My Twitter Website Offline
// Written by:  Michael Baranowski, December 2022

	echo "<br>&nbsp;&nbsp;$desc_short is off-line for maintenance, please try again later.<br><br>"

?>