<?php
// page2.php - Page 2
// Written by:  Programmer, Date	

// Verify that program was called from Landing Page and LOGON
	require('landing.php');

// Output
	echo "<p>Page 2<p>";
?>