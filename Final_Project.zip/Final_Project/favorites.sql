-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 16, 2022 at 04:06 AM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bcs350`
--

-- --------------------------------------------------------

--
-- Table structure for table `favorites`
--

DROP TABLE IF EXISTS `favorites`;
CREATE TABLE IF NOT EXISTS `favorites` (
  `favid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `userid` int(10) UNSIGNED NOT NULL,
  `figid` int(10) UNSIGNED NOT NULL,
  `name` varchar(50) NOT NULL,
  `info` varchar(250) NOT NULL,
  `color` varchar(20) NOT NULL,
  `photo` varchar(250) NOT NULL,
  PRIMARY KEY (`favid`),
  KEY `userid_fk` (`userid`),
  KEY `figid_fk` (`figid`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `favorites`
--

INSERT INTO `favorites` (`favid`, `userid`, `figid`, `name`, `info`, `color`, `photo`) VALUES
(54, 3, 2, 'Peters Honey', 'Very Sweet and has an amber colored flesh. Can eat by itself or make preserves out of it. Need a lot of sun and heat to ripen.', 'Light Green', 'images/peters_honey_fig.jpg'),
(55, 4, 6, 'Brown Turkey', 'Bigger fruits light pink flesh with fewer seeds than other figs. They have a milder flavor than others. Can be used in salads', 'Brown', 'images/brown_turkey_fig.jpg'),
(56, 4, 9, 'Caprifigs', 'Only produce male flowers and never bear fruit. Only purpose is to pollinate other fig trees', 'Light Green', 'images/caprifig.jpg'),
(68, 3, 3, 'Black Mission', 'Most common variety. Small with solid pink flesh and a chewy texture. Good to eat plain. Originated in Spain', 'Black', 'images/black_mission.jpg'),
(69, 10, 10, 'LSU Improved Celeste', 'Ripens early produces a lot of fruit. Provides sweet sugar taste. Dark amber flesh. Fun Fact: LSU Improved Celeste was selectively bred by Louisiana State University (LSU) researchers and spread quickly in the area without LSU formally releasing it.', 'Brown/Purple', 'images/LSU_improved_celeste_fig.jpg'),
(70, 10, 4, 'Mediterranean', 'Red Flesh. High sugar content makes it great for drying or using in fig bars and pastes.', 'Light Green', 'images/mediterranean_fig.jpg'),
(71, 32, 5, 'Celeste', 'Ripen early and have high sugar content so they can be used in desserts', 'Brown', 'images/celeste_fig.jpg'),
(72, 32, 7, 'Calimyrna', 'Large, soft, delicious fruits. Pink insides. Great choice to serve by itself or serve with nuts.', 'Light Green', 'images/calimyrna_fig.jpg');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `favorites`
--
ALTER TABLE `favorites`
  ADD CONSTRAINT `figid_fk` FOREIGN KEY (`figid`) REFERENCES `figs` (`figid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `userid_fk` FOREIGN KEY (`userid`) REFERENCES `final_project_users` (`rowid`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
