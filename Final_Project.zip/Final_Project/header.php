	<?php
// header.php - Page Header
// Written by: Michael Baranowski, November 2022

// Page Header
	echo "<!doctype html>
		  <body>
		  <table width='$width' align='center' cellpadding='0' cellspacing='0' style='border:1px solid black;'>\n
		  <tr><td align='center' style='$hdr_style'>$desc_short</td></tr>\n
		  <tr><td align='center' style='$hdr_style2'><br>Hello, $sname <br><br></td></tr>\n
		  </table>";		  
?>