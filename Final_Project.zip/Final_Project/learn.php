<?php
// learn.php - Learn Page
// Written by:  Michael Baranowski, December 2022	

// Verify that program was called from Landing Page
	require('landing.php');

// Output Page  
	echo"<!doctype HTML>
	 <html>
	 <body>
	 <center>
	 <h1>Learn all about Figs!</h1>";
	 //Out put text in bold saying "Learn how to get started with growing figs!"
	 echo"<p><b>Learn how to get started with growing figs!</b></p>";
	 //Embeds the video into the webpage
	 echo"<iframe width='400' height='350' src='https://www.youtube.com/embed/9w-e4k-3Tz8' title='How to Grow Figs - Complete Growing Guide' frameborder='0' allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>";
	 //Out put text in bold saying "Learn how to graft figs."
	 echo"<p><b>Learn how to graft figs.</b><p>"; 
	 //Embeds the video into the webpage
	 echo"<iframe width='400' height='350' src='https://www.youtube.com/embed/NBV9OIfQlaY' title='Grafting Fruit Trees | The 2 Best Techniques for Grafting Figs and other fruit trees' frameborder='0' allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>";
	 //Out put text in bold saying "Learn more about Caprifigs!"
	 echo"<p><b>Learn more about Caprifigs!</b></p>";
	 //Embeds the video into the webpage
	 echo"<iframe width='400' height='350' src='https://www.youtube.com/embed/2uEXG-1KFjk' title='Male Figs / caprifigs are just flowers! Look closely! (Ficus carica)' frameborder='0' allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>";
	 //Out put text in bold saying "Learn how to make Fig Jam!"
	 echo"<p><b>Learn how to make Fig Jam!</b></p>";
	 //Embeds the video into the webpage
	 echo";<iframe width='400' height='350' src='https://www.youtube.com/embed/ARc0tsq6e_o' title='How to make Fig Jam - Homemade Jam Recipe' frameborder='0' allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>";
	 //Out put text in bold saying "Learn how to make fig bars!"
	 echo"<p><b>Learn how to make fig bars!</b></p>";
	 //Embeds the video into the webpage
	 echo"<iframe width='400' height='350' src='https://www.youtube.com/embed/gatg9vhCl_A' title='Fig Bars Homemade Recipe Tutorial | Healthy Home Cooking | From Garden to Table | Fast Tasty Meal' frameborder='0' allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>";
	 //Out put text in bold saying "Gordon Ramsey demonstrates a unique way to cook Figs."
	 echo"<p><b>Gordon Ramsey demonstrates a unique way to cook Figs.</b></p>";
	 //Embeds the video into the webpage
	 echo"<iframe width='400' height='350' src='https://www.youtube.com/embed/BKqnwq5pgsY' title='Caramelised Figs with Balsamic Vinegar, Rosemary and Ricotta | Gordon Ramsay' frameborder='0' allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>";
?>