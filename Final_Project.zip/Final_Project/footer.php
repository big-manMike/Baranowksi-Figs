<?php
// footer.php - Page Footer
// Written by: Michael Baranowski, December 2022

	echo "<table width='$width' align='center' cellpadding='0' cellspacing='0' style='$ftr_style'>\n
		  <tr><td align='center'>$footer</td></tr>\n
		  </table>
		  </body>";
?>