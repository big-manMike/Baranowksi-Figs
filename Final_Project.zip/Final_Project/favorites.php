<?php
// favorites.php - Favorites Page
// Written by:  Michael Baranowski, December 2022	

// Verify that program was called from Landing Page and LOGON
	require('landing.php');
	require('mysqli_connect.php');

//Variables
$table="favorites";
$table2="final_project_users";
$table3="figs";
$clmns=array("figid", "name", "info", "color", "photo");
$td="style='font-weight:bold'";

//If user is logged in then Favorites List is accessable
if($suser!="Guest"){
	//Create query and Execute
	$query="SELECT figid, name, info, color, photo FROM favorites WHERE userid=$suser";
	$result=mysqli_query($mysqli, $query);
	if(!$result) echo"Query Error [$query]: ".mysqli_error($mysqli);

	// Output
	echo "<center>
		  <p>$sname's Favorite's List ";
	//Display Favorite's List
	//Column Headings
	echo"<p><table align='center' rules='all' border='frame' celpadding='3'>
		 <tr>
		 <td $td align='center'>Fig</td>
		 <td $td align='center'>Name</td>
		 <td $td align='center'>Info</td>
		 <td $td align='center'>Color</td>
		 <td $td align='center'>Photo</td>
		 </tr>";

	//Body
	while(list($figid, $name, $info, $color, $photo)=mysqli_fetch_row($result)){
		echo"<tr>
			 <td align='right'>$figid</td>
			 <td align='center'>$name</td>
			 <td align='center'>$info</td>
			 <td align='center'>$color</td>
			 <td><image src=$photo width='100'></td>
			 </tr>";
	}
//End of Page
	echo"</table>";
}
//If user is not logged in then they can't see Favorites List 
else{
	echo"<center>
		 <h1>You need to log in in order to see Favorites List</h1>";
} 
?>