<?php
// figs.php - Figs List page
// Written by:  Michael Baranowski, December 2022	

// Verify that program was called from Landing Page and LOGON
	require('landing.php');
	require('mysqli_connect.php');

//Variables
$table="figs";
$clmns=array("Name","Color");
$sorts=array("Ascending", "Descending");
$clmns2=array("figid", "name", "info", "color", "photo");
$td="style='font-weight:bold'";
$msg=null;

//Get Sort Input
if(isset($_POST['clmn'])) $clmn=$_POST['clmn']; else $clmn='name';

//Get Ascending or Descending
if(isset($_POST['clmn2'])) $clmn2=$_POST['clmn2']; else $clmn2=null;
if($clmn2=='Descending') $sort='DESC'; else $sort=null;

//Procss Input
switch($clmn){
	case 'Name': $sortby='name';break;
	case 'Color': $sortby='color';break;
	default: $sortby='name';break;
}

//Create query and execute
$query="SELECT figid, name, info, color, photo FROM $table ORDER BY $sortby $sort ";
$result=mysqli_query($mysqli, $query);
if(!$result) echo"Query Error [$query]:".mysqli_error($mysqli);

//Column Dropdown
echo"<center>
	 <h1>Fig List</h1>
	 <p><form action='$pgm?p=figs' method='post'>
	 Sort By: <select name='clmn' onchange='this.form.submit()'>";
foreach($clmns as $value){
	if($value==$clmn) $se='SELECTED'; else $se=null;
	echo"<option $se>$value</option>";
}
echo"</select>";
//Ascending or Descending Dropdown
echo"<select name='clmn2' onchange='this.form.submit()'>";
foreach($sorts as $value){
	if($value==$clmn2) $se='SELECTED'; else $se=null;
	echo"<option $se>$value</option>";
}
echo"</select></form>";

//Display Fig list
//Column Headings
echo"<p><table align='center' rules='all' border='frame' celpadding='3'>
	 <tr>
	 <td $td align='center'>Name</td>
	 <td $td align='center'>Info</td>
	 <td $td align='center'>Color</td>
	 <td $td align='center'>Photo</td>
	 <td $td align='center'>Favorite</td>
	 </tr>";

//Body
echo"<form method='post' action='$pgm?p=figs'>";
while(list($figid, $name, $info, $color, $photo)=mysqli_fetch_row($result)){
	//Gets the figid and appends it to favorite to match the figid in the table to use as the name of each   
	$favoriteNum='favorite'.$figid;
	//Prevents Guest from adding to Favorite List
	if($suser!="Guest"){
		//Gets the input  
		if(isset($_POST[$favoriteNum])){
			$fav_query="INSERT INTO favorites (userid, figid, name, info, color, photo)
			VALUES ('$suser', '$figid', '$name', '$info', '$color', '$photo')";
			$favResult=mysqli_query($mysqli, $fav_query);
			if($favResult) echo"<script>alert('Fig added to Favorites List')</script>";
		}
	}
	//Prints this message at end of the page if Guest
	else $msg="Needed to be logged in to add to Favorites List";
	
	echo"<tr>
		 <td align='center'>$name</td>
		 <td align='center'>$info</td>
		 <td align='center'>$color</td>
		 <td><image src=$photo width='100'></td>
		 <td><input type='submit' name='$favoriteNum' value='Add to Favorites'></td>
		 </tr>";
}
//End of Page
echo"</form>";
echo"</table>";
echo"<b>$msg</b>"
?>